package com.client;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;

import com.chunkserver.ChunkServer;
import com.interfaces.ClientInterface;

/**
 * implementation of interfaces at the client side
 * @author Shahram Ghandeharizadeh
 *
 */
public class Client implements ClientInterface {
	static int ServerPort = 3011;
	static Socket ClientSocket;
	static ObjectOutputStream WriteOutput;
	static ObjectInputStream ReadInput;
	
	public static byte[] RecvPayload(String caller, ObjectInputStream instream, int sz){
		byte[] tmpbuf = new byte[sz];
		byte[] InputBuff = new byte[sz];
		int ReadBytes = 0;
		while (ReadBytes != sz){
			int cntr=-1;
			try {
				cntr = instream.read( tmpbuf, 0, (sz-ReadBytes) );
				for (int j=0; j < cntr; j++){
					InputBuff[ReadBytes+j]=tmpbuf[j];
				}
			} catch (IOException e) {
				System.out.println("[Client] RecvPayload: " + caller + " " + instream + " " +sz);
				System.out.println("Error in RecvPayload ("+caller+"), failed to read "+sz+" after reading "+ReadBytes+" bytes.");
				return null;
			}
			if (cntr == -1) {
				System.out.println("Error in RecvPayload ("+caller+"), failed to read "+sz+" bytes.");
				return null;
			}
			else ReadBytes += cntr;
		}
		return InputBuff;
	}
	
	public static int ReadIntFromInputStream(String caller, ObjectInputStream instream){
		int PayloadSize = -1;
		
		byte[] InputBuff = RecvPayload(caller, instream, 4);
		if (InputBuff != null)
			PayloadSize = ByteBuffer.wrap(InputBuff).getInt();
		return PayloadSize;
	}
	
	/**
	 * Initialize the client  FileNotFoundException
	 */
	public Client(){
		if (ClientSocket != null) return; //The client is already connected
		try {
			
			System.out.println("[Client] Directed to use master's port: " + ServerPort);
			
			ClientSocket = new Socket("localhost", ServerPort);
			System.out.println("[Client] Connected to ChunkServer: localhost, " + ServerPort);
			
			WriteOutput = new ObjectOutputStream(ClientSocket.getOutputStream());
			ReadInput = new ObjectInputStream(ClientSocket.getInputStream());
			System.out.println("...");
			WriteOutput.writeObject(new String("Client"));
			WriteOutput.flush();
			
			System.out.println("[Client] Fully connected to ChunkServer: localhost, " + ServerPort);
		}catch (IOException e) {
			e.printStackTrace();
		}
	}

	public String createChunk() {
		// TODO Auto-generated method stub
		
		InputStream input = null;
		OutputStream output = null;
		try {
			input = ClientSocket.getInputStream();
			output = ClientSocket.getOutputStream();
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		
		DataOutputStream dOut = new DataOutputStream(output);
		DataInputStream dIn = new DataInputStream(input);
		
		byte [] request_bytes = ByteBuffer.allocate(4).putInt(0).array();
		
		try {
			
			
			dOut.write(request_bytes);
			dOut.flush();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		String handle = null;
		
		
		while(handle == null)
		{	
			try {
					int count = dIn.available();
					
					if(count > 0)
					{
						byte [] handle_bytes = new byte[count];
						dIn.read(handle_bytes);
						handle = new String(handle_bytes, Charset.forName("UTF-8"));
					}
					
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		
		
		return handle;
		
	}
	@Override
	public boolean writeChunk(String ChunkHandle, byte[] payload, int offset) {
		// TODO Auto-generated method stub
		InputStream input = null;
		OutputStream output = null;
		try {
			input = ClientSocket.getInputStream();
			output = ClientSocket.getOutputStream();
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		
		DataOutputStream dOut = new DataOutputStream(output);
		DataInputStream dIn = new DataInputStream(input);
		
		// format of message is [protocol_int__payload_size__chunk_handle__payload__offset]
		int p_size = payload.length;
		
		byte [] write_request = ByteBuffer.allocate(4).putInt(1).array();
		byte [] p_size_bytes = ByteBuffer.allocate(4).putInt(p_size).array();
		byte [] handle_bytes = ChunkHandle.getBytes(Charset.forName("UTF-8"));
		byte [] offset_bytes = ByteBuffer.allocate(4).putInt(offset).array();
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream( );
		
		try {
			outputStream.write(write_request);
			outputStream.write(p_size_bytes);
			outputStream.write(handle_bytes);
			outputStream.write(payload);
			outputStream.write(offset_bytes);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		byte [] message = outputStream.toByteArray();
		
		try {
			outputStream.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try {
			dOut.write(message);
			dOut.flush();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		int accepted = -1;
		
		while(accepted == -1)
		{
			try {
				int count = dIn.available();
				
				if(count > 0)
				{
					byte [] response = new byte[count];
					dIn.read(response);
					accepted = ByteBuffer.wrap(response).getInt();
				}
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		if(accepted == 1)
		{
			return true;
		}
		
		else if(accepted == 0)
		{
			return false;
		}
		
		return false;
		
	}
	@Override
	public byte[] readChunk(String ChunkHandle, int offset, int NumberOfBytes) {
		// TODO Auto-generated method stub
		
		InputStream input = null;
		OutputStream output = null;
		try {
			input = ClientSocket.getInputStream();
			output = ClientSocket.getOutputStream();
		} catch (IOException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		
		
		DataOutputStream dOut = new DataOutputStream(output);
		DataInputStream dIn = new DataInputStream(input);
		
		// format of message is [protocol_int__chunk_handle__offset__num_bytes]
		byte [] read_request = ByteBuffer.allocate(4).putInt(2).array();
		byte [] handle_bytes = ChunkHandle.getBytes(Charset.forName("UTF-8"));
		byte [] offset_bytes = ByteBuffer.allocate(4).putInt(offset).array();
		byte [] num_bytes = ByteBuffer.allocate(4).putInt(NumberOfBytes).array();
		
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream( );
		try {
			outputStream.write(read_request);
			outputStream.write(handle_bytes);
			outputStream.write(offset_bytes);
			outputStream.write(num_bytes);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		byte [] message = outputStream.toByteArray();
		
		
		try {
			dOut.write(message);
			dOut.flush();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		boolean accepted = false;
		byte [] payload = null;
		while(!accepted)
		{
			int count = 0;
			int messageLength = 0;
			outputStream = new ByteArrayOutputStream( );
			byte [] standardMessage = null;
			try
			{
				while(dIn.available() > 0)
				{	
					// should be done within 5 reads
					if(count > 5)
						
						
					{
						break;
					}
					
					
					standardMessage = new byte[dIn.available()];
					messageLength = standardMessage.length;
					dIn.read(standardMessage);
					outputStream.write(standardMessage);
					
					count++;
					accepted = true;
				}
			}
			
			 catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		}
			
			payload = outputStream.toByteArray();
			

		return payload;
		//return cs.readChunk(ChunkHandle, offset, NumberOfBytes);
	}

	
	public static void main(String[] args) {
		Client c = new Client();
		
	}

	


}
