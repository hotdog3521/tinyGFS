/*
package com.chunkserver;

import com.interfaces.ChunkServerInterface;

public class ChunkServerNew implements ChunkServerInterface, Runnable {

	@Override
	public String createChunk() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean writeChunk(String ChunkHandle, byte[] payload, int offset) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public byte[] readChunk(String ChunkHandle, int offset, int NumberOfBytes) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public void run(){
		
	}
	
}
























*/
package com.chunkserver;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.RandomAccessFile;
import java.io.Writer;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Queue;
import java.util.UUID;

import com.interfaces.ChunkServerInterface;


//determine port number for client : 3001

/**
 * implementation of interfaces at the chunkserver side
 * @author Shahram Ghandeharizadeh and Jason Gui
 * 
 * 1. Client asks master which chunkserver has the lease for a chunk.
 * 2. The master gives client a primary server and list of other secondary servers. (More...)
 * 3. All chunkservers (primary & secondary) get data&control from the client.
 * 4. 
 * 
 * Our version should NOT decouple data and control (makes it simpler to code)
 *
 */
// TinyFS Part 2 Final

public class ChunkServer implements ChunkServerInterface, Runnable {
	
	public final static int MessageLength = 10000;
	public final static int ChunkSize = 4 * 1024; //4 KB chunk sizes
	final static String filePath = "csci485";	//or C:\\newfile.txt
	protected int port = 3001;
	protected ServerSocket serverSocket = null;
	protected boolean isStopped = false;
	protected Thread runningThread = null;
	
	//added for part 3
	int portToMaster = 9999;
	//ArrayList<String> chunksInOperation = new ArrayList<>();	//which chunks does this server have a lease on? held by master!!
	
	Queue<ChunkOperation> lease;			//if starts with empty => primary, else => secondary
	
	boolean isPrimary;
	
	String[] otherChunkServerIP = {"localhost", "localhost"};
	int[] otherChunkServerPorts = {3000, 3000};
	//TODO add some logging fxn
	
	
	
	
	/**
	 * Initialize the chunk server
	 * @throws IOException 
	 */

	public ChunkServer(int port) {
		this.port = port;
		//otherChunkServerIP = ; //TODO write method to get these values
		//otherChunkServerPorts = ;
	}
	
	public ChunkServer(){
		this.port = 3001;
	}
	
	//Adds the chunk operation that was just done to the lease queue (to give to secondaries).
	//Only works if chunkserver is primary.
	//Do this at the end of each operation that's received from client.
	public void updateLease(ChunkOperation co) {
		if(isPrimary) {
			lease.add(co);
		}
	}
	
	//Goes through the queue and executes all the chunk operations in order
	//Only works if chunkserver is secondary (NOT isPrimary)
	//This method is called during getLease(...)
	public void getUpToDate(Queue<ChunkOperation> lease) {
		if(isPrimary) return;
		while(lease.size() >= 0) {
			ChunkOperation co = lease.poll();
			if(co.command == 0) createChunk();
			else if(co.command == 1) writeChunk(co.chunkhandle, co.chunk, co.offset);
			else if(co.command == 2) readChunk(co.chunkhandle, co.offset, co.numBytes);
			else System.out.println("Error: Command is weirdly formatted");
		}
	}
	
	//Waits for the master to give the lease, then takes it.
	//Checks if lease is empty -> if not, this server is secondary and executes all operations in lease.
	//If empty -> This makes this chunkserver primary. (done in method)
	//This method is blocking. (?)
	public Queue<ChunkOperation> getLease(String masterIP) {
		int masterPort = 3000;
		Socket s;
		Queue<ChunkOperation> lease_received = null;
		
		try {
			s = new Socket(masterIP, masterPort);
			ObjectInputStream ois = new ObjectInputStream(s.getInputStream());
			lease_received = (Queue<ChunkOperation>)ois.readObject();
			ois.close();
			
			if(lease_received.size() == 0) isPrimary = true;
			else isPrimary = false;
			
			System.out.println("Chunkserver: Lease was received successfully");
			
		} catch(IOException ioe) {
			ioe.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		if(!isPrimary) getUpToDate(lease_received);
		
		return lease_received;
	}
	
	
	//Sends this lease to all secondary servers. <Read section 3.1, steps 5 & 6>
	//This should only be done if this chunkserver isPrimary and is done with mutations
	//This method prints progress messages.
	public boolean sendLeaseToAllSecondaries(Queue<ChunkOperation> lease_to_send, String[] secondaryIP, int[] secondaryPorts) {
		Socket s;
		
		//quits if IP[] and Ports[] does not match in length
		if(secondaryIP.length != secondaryPorts.length) {
			System.out.println("Error: secondaryIP, secondaryPorts not formatted correctly");
			return false;
		}
		
		//Goes through all secondaries and sends them the lease (via. serialization)
		//Waits to get a confirmation Integer(1) from current secondary before giving to next secondary.
		for(int i = 0; i < secondaryPorts.length; i++) {
			try {
				s = new Socket(secondaryIP[i], secondaryPorts[i]);
				ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream());
				oos.writeObject(lease_to_send);
				oos.flush();
				
				ObjectInputStream ois = new ObjectInputStream(s.getInputStream());
				Integer confirmation = (Integer) ois.readObject();
				if(confirmation == 1) {
					oos.close();
					s.close();
					System.out.println("Chunkserver: Lease sent to secondary: " + secondaryIP[i] + " successfully.");
				} else {
					System.out.println("Error: Chunk operations were not done successfully on "+secondaryIP[i]+". Stopping...");
					return false;
				}
				
			} catch(IOException ioe) {
				ioe.printStackTrace();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
		}
		return true; //everything worked
	}
	
	
	//This should only be called after sendLeaseToAllSecondary was successfully complete.
	//<Read section 3.1, step 7>
	//error == "fail" sends to client: Integer(0)
	//error != "fail" sends to client: Integer(1)
	public void replyToClient(String clientIP, int clientPort, String error) {
		Socket s;
		Integer message;
		
		//make message to send to client
		if(error.equals("fail")) {
			message = new Integer(0);
		} else {
			message = new Integer(1);
		}
		
		//send the message to client
		try {
			s = new Socket(clientIP, clientPort);
			ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream());
			oos.writeObject(message);
			oos.flush();
			oos.close();
		} catch(IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	
	
	
	private void openServerSocket() {
		try {
			this.serverSocket = new ServerSocket(this.port);
		} catch (IOException e) {
			
			throw new RuntimeException("Cannont open port " + this.port, e);
		}
	}
	
	private synchronized boolean isStopped() {
		return this.isStopped;
	}
	
	public synchronized void stop (){
		this.isStopped = true;
		
		try{
			this.serverSocket.close();
		}catch(IOException e){
			throw new RuntimeException("Error closing server", e);
		}
	}
	
	
	public void run()
	{		
		synchronized(this){
			this.runningThread = Thread.currentThread();
		}
		
		openServerSocket();
		System.out.println("Server running...");
		while(!isStopped())
		{		
				 
				try {
					Socket clientSocket = this.serverSocket.accept();
					new Thread(new WorkerRunnable(clientSocket, this)).start();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
		}
		System.out.println("Server stopped");
		
	}
	
	public String createChunk() {
		
		File dir = new File(filePath);
		
		if(!dir.exists())
		{
			dir.mkdir();
		}
		
		String guid_chunk = generateGUID();
		String path = filePath + File.separator + guid_chunk;
		File file = new File(path);
		
		
		return guid_chunk;
	}
	
	public String generateGUID(){
		UUID guid = UUID.randomUUID();
		long bits = guid.getLeastSignificantBits();
		String hex = Long.toHexString(bits);
		String uid = hex.substring(0, 8) + "-" + hex.substring(8, hex.length());
		return uid;
	}
	
	@Override	
	// offset + payload is the byte range
	public boolean writeChunk(String ChunkHandle, byte[] payload, int offset) {
		// TODO Auto-generated method stub
		
		File chunk = new File(ChunkHandle);
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(chunk);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		// offset is offset within a record
		
		if(offset + payload.length > ChunkSize)
		{	
			int padBytes = offset + payload.length - ChunkSize;
			byte [] padding = new byte[padBytes];
			try {
				fos.write(padding, offset, padding.length);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return false;
		}
		
		else
		{	
			try {
				fos.write(payload, offset, payload.length);
				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return true;
		}
	}
	
	@Override
	// offset + numberOfBytes is the byte range
	
	
	public byte[] readChunk(String ChunkHandle, int offset, int NumberOfBytes) {
		
		File file = new File(ChunkHandle);
		byte [] load = null;
		if(!file.exists())
		{
			return null;
		}
		
		FileInputStream fis;
		try {
			fis = new FileInputStream(file);
			load = new byte[NumberOfBytes];
			fis.read(load, offset, NumberOfBytes);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return load;
	}
	
	
	public static void main(String [] args)
	{
		ChunkServer cs = new ChunkServer(3001);
		new Thread(cs).start();
		
	}

}

class WorkerRunnable implements Runnable{
	
	protected Socket clientSocket;
	protected ChunkServer cs;
	
	public  WorkerRunnable(Socket clientSocket, ChunkServer chunkServer)
	{
		this.clientSocket = clientSocket;
        this.cs   = chunkServer;
        cs.getLease("localhost");		//TODO change localhost to actual master IP
	}
	
	@Override
	public void run() {
		InputStream input = null;
		OutputStream output = null;
		
		try {
			input = clientSocket.getInputStream();
			output = clientSocket.getOutputStream();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		DataInputStream dIn = new DataInputStream(input);
		DataOutputStream dOut = new DataOutputStream(output);
			
		//only executes when cs is expecting data from client (isPrimary)
		int timer = 0;//runs for about 10 seconds, then sends lease to master to be replicated
		while(!cs.isStopped && cs.isPrimary){ //while true loop listens for incoming data
			
			try { //timer
				Thread.sleep(10);
				timer++;
				if(timer > 1000) { //if while loop has been listening for 10 seconds
					timer = 0;
					if(cs.sendLeaseToAllSecondaries(cs.lease, cs.otherChunkServerIP, cs.otherChunkServerPorts));
						//cs.replyToClient("localhost", clientPort, "none");
					else {
						//cs.replyToClient("localhost", clientPort, "fail"); //TODO add clientPort
					}
					break;
				}
			} catch (InterruptedException e2) {
				e2.printStackTrace();
			}
				
			byte [] standardMessage = null;
			byte [] message = null;
			int messageLength = 0;
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream( );
			try {
					int count = 0;
					
					while(dIn.available() > 0) //when it detects some data coming in
					{	
						if(count > 5) break;	//should be done within 5 reads
						
						standardMessage = new byte[dIn.available()];
						messageLength = standardMessage.length;
						dIn.read(standardMessage);
						outputStream.write(standardMessage);
						count++;
					}
					
					message = outputStream.toByteArray();
					messageLength = message.length;
				}
				
			 catch (IOException e1) {
				e1.printStackTrace();
			}
			
			
			if(messageLength > 0)
			{
				byte [] code = new byte[4];
				
				for(int i = 0; i < code.length; i++) code[i] = message[i]; //takes the first 4 bytes of message
			
				int command = ByteBuffer.wrap(code).getInt();
				
				
				// create chunk <command==0>
				if(command == 0) {	
					String handle = cs.createChunk();
					byte[] bytes_handle = handle.getBytes(Charset.forName("UTF-8"));
					
					try { //sends chunkhandle back to client
						dOut.write(bytes_handle);
						dOut.flush();
					} catch (IOException e) {
						e.printStackTrace();
					}
					
					//execute and add to lease
					cs.updateLease(new ChunkOperation(0, handle, new byte[0], 0, 0));
					
				}
				
				// write chunk <command==1>
				else if(command == 1) {	
					
					//gets bytes 5-8 = loadsize
					byte [] load_size_bytes = new byte [4];
					
					for(int i = 0; i < load_size_bytes.length; i++) 
						load_size_bytes[i] = message[i + 4];
					
					int load_size = ByteBuffer.wrap(load_size_bytes).getInt();
					
					
					//gets chunkhandle, then payload
					byte [] payload = new byte[load_size];
					byte [] handle_bytes = new byte[17];
					
					for(int i = 0; i < handle_bytes.length; i++) //gets bytes 9-26 = handle
						handle_bytes[i] = message[i + 8];
					
					for(int i = 0; i < payload.length; i++)
						payload[i] = message[i + 8 + 17];
					
					String handle = new String(handle_bytes, Charset.forName("UTF-8"));
					
					
					//gets offset, last 4 bytes
					byte [] offset_bytes = new byte[4];
					
					for(int i = 0; i < offset_bytes.length; i++)
						offset_bytes[i] = message[i + 8 + 17 + payload.length];
					
					int offset = ByteBuffer.wrap(offset_bytes).getInt();
					
					//runs writeChunk, then sends client success or fail message (int 1 or 0 to byte[])
					if(cs.writeChunk(handle, payload, offset)) {	
						byte [] write_request = ByteBuffer.allocate(4).putInt(1).array();
						
						try {
							dOut.write(write_request);
							dOut.flush();
						} catch (IOException e) {
							e.printStackTrace();
						}
					} else {
						byte [] write_request = ByteBuffer.allocate(4).putInt(0).array();
					
						try {
							dOut.write(write_request);
							dOut.flush();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				}
				
				else if(command == 2){
					byte [] handle_bytes = new byte [17];
					for(int i = 0; i < handle_bytes.length; i++)
					{
						handle_bytes[i] = message[i + 4];
					}
					
					String handle = new String(handle_bytes, Charset.forName("UTF-8"));
					
					byte [] offset_bytes = new byte[4];
					for(int i = 0; i < offset_bytes.length; i++)
					{
						offset_bytes[i] = message[i + 4 + 17];
					}
					
					int offset = ByteBuffer.wrap(offset_bytes).getInt();
					
					byte [] num_bytes = new byte[4];
					
					for(int i = 0; i < num_bytes.length; i++)
					{
						num_bytes[i] = message[i + 8 + 17];
					}
					
					int number_of_bytes = ByteBuffer.wrap(num_bytes).getInt();
					
					byte [] load = cs.readChunk(handle, offset, number_of_bytes);
					
					try {
						dOut.write(load);
						dOut.flush();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		
		
		}
	}
	
}


