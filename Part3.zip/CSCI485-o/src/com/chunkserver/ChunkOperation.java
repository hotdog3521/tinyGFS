package com.chunkserver;

//This class is used for the lease and cache. This information comes in from the client
//to the chunkservers.

public class ChunkOperation {
	
	//0 = createChunk
	//1 = writeChunk
	//2 = readChunk
	
	int command;
	String chunkhandle;
	byte[] chunk;
	int offset;
	int numBytes;
	
	public ChunkOperation(int command, String chunkhandle, byte[] chunk, int offset, int numBytes) {
		this.command = command;
		this.chunkhandle = chunkhandle;
		this.chunk = chunk;
		this.offset = offset;
		this.numBytes = numBytes;
	}
	
}
